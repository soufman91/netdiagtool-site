using System;
using System.Windows.Forms;

namespace NetDiagTool
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (!LicenseManager.IsActivated())
            {
                using (var f = new ActivationForm())
                {
                    if (f.ShowDialog() != DialogResult.OK)
                        return;
                }
            }

            Application.Run(new MainForm());
        }
    }
}
