using System;
using System.Windows.Forms;

namespace NetDiagTool
{
    public class AboutForm : Form
    {
        public AboutForm()
        {
            this.Text="À propos de NetDiagTool";
            this.Width=380;
            this.Height=220;
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            var lbl=new Label();
            lbl.Text="NetDiagTool v3\n© 2025 Soufiane Mansour\nTous droits réservés.\n\nOutil de diagnostic réseau et test de ports.";
            lbl.Dock=DockStyle.Fill;
            lbl.TextAlign=System.Drawing.ContentAlignment.MiddleCenter;

            this.Controls.Add(lbl);
        }
    }
}
