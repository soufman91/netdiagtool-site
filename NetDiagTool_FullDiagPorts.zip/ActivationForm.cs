using System;
using System.IO;
using System.Windows.Forms;

namespace NetDiagTool
{
    public static class LicenseManager
    {
        public const string ValidKey = "NET-2025-XYZ-1234";

        private static string Folder =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NetDiagTool");

        private static string FilePath =>
            Path.Combine(Folder, "license.dat");

        public static bool IsActivated()
        {
            try
            {
                if (!File.Exists(FilePath)) return false;
                return File.ReadAllText(FilePath).Trim() == ValidKey;
            }
            catch { return false; }
        }

        public static bool SaveKey(string key)
        {
            try
            {
                if (key.Trim() != ValidKey) return false;
                if (!Directory.Exists(Folder)) Directory.CreateDirectory(Folder);
                File.WriteAllText(FilePath, key.Trim());
                return true;
            }
            catch { return false; }
        }
    }

    public class ActivationForm : Form
    {
        TextBox txt;
        public ActivationForm()
        {
            this.Text="Activation NetDiagTool";
            this.Width=380; this.Height=160;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            var lbl=new Label(){Left=10,Top=10,Text="Entrez votre clé de série :"};
            txt=new TextBox(){Left=10,Top=35,Width=340};
            var ok=new Button(){Text="Valider",Left=200,Top=70,Width=70};
            var cancel=new Button(){Text="Quitter",Left=280,Top=70,Width=70};

            ok.Click += (s,e)=>{
                if (LicenseManager.SaveKey(txt.Text))
                {
                    MessageBox.Show("Clé acceptée. Merci.", "NetDiagTool",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult=DialogResult.OK;
                    this.Close();
                }
                else MessageBox.Show("Clé invalide.", "Erreur",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            };
            cancel.Click += (s,e)=>{ this.DialogResult=DialogResult.Cancel; this.Close(); };

            this.Controls.Add(lbl);
            this.Controls.Add(txt);
            this.Controls.Add(ok);
            this.Controls.Add(cancel);
        }
    }
}
