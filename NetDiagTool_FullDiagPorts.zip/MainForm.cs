using System;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Drawing;

namespace NetDiagTool
{
    public class MainForm : Form
    {
        TextBox output;
        Button btnDiag, btnClear, btnAbout;
        GroupBox grpPorts;
        TextBox txtHost;
        CheckedListBox chk;
        Button btnPorts;

        public MainForm()
        {
            this.Text="NetDiagTool v3 - Diagnostic réseau + ports";
            this.Width=1100;
            this.Height=650;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Boutons haut
            btnDiag=new Button(){Text="Diagnostic complet",Left=10,Top=10,Width=160};
            btnClear=new Button(){Text="Effacer",Left=180,Top=10,Width=80};
            btnAbout=new Button(){Text="À propos",Left=270,Top=10,Width=90};

            btnDiag.Click += (s,e)=>RunDiag();
            btnClear.Click += (s,e)=>output.Clear();
            btnAbout.Click += (s,e)=> new AboutForm().ShowDialog(this);

            // Zone de sortie
            output=new TextBox(){
                Multiline=true,ScrollBars=ScrollBars.Both,ReadOnly=true,
                Font=new Font("Consolas",9),
                Left=10,Top=50,
                Width=750,Height=550
            };

            // Colonne diag ports
            grpPorts=new GroupBox(){
                Text="Diag ports TCP",
                Left=770,Top=50,Width=300,Height=550
            };

            var lblHost=new Label(){Text="Hôte (IP / nom) :",Left=10,Top=25,AutoSize=true};

            var lineHost = new Label(){
                Left = 10,
                Top = lblHost.Bottom + 2,
                Width = grpPorts.Width - 20,
                Height = 2,
                BorderStyle = BorderStyle.Fixed3D
            };

            txtHost=new TextBox(){Left=10,Top=lineHost.Bottom+5,Width=grpPorts.Width-20,Text="192.168.1.1"};

            var lblPorts=new Label(){Text="Ports à tester :",Left=10,Top=txtHost.Bottom+10,AutoSize=true};

            var linePorts = new Label(){
                Left = 10,
                Top = lblPorts.Bottom + 2,
                Width = grpPorts.Width - 20,
                Height = 2,
                BorderStyle = BorderStyle.Fixed3D
            };

            chk=new CheckedListBox(){
                Left=10,Top=linePorts.Bottom+5,
                Width=grpPorts.Width-20,
                Height=350
            };

            chk.Items.AddRange(new string[]{
                "20 (FTP data)",
                "21 (FTP)",
                "22 (SSH)",
                "23 (Telnet)",
                "25 (SMTP)",
                "53 (DNS)",
                "80 (HTTP)",
                "110 (POP3)",
                "135 (RPC)",
                "139 (NetBIOS)",
                "143 (IMAP)",
                "389 (LDAP)",
                "443 (HTTPS)",
                "445 (SMB)",
                "465 (SMTPS)",
                "587 (SMTP submit)",
                "636 (LDAPS)",
                "993 (IMAPS)",
                "995 (POP3S)",
                "1433 (SQL Server)",
                "3306 (MySQL)",
                "3389 (RDP)",
                "5432 (PostgreSQL)",
                "5900 (VNC)",
                "8080 (HTTP alt)",
                "8443 (HTTPS alt)"
            });

            btnPorts=new Button(){
                Text="Tester les ports sélectionnés",
                Left=10,
                Width=grpPorts.Width-20,
                Top=chk.Bottom+10
            };
            btnPorts.Click += (s,e)=>TestPorts();

            grpPorts.Controls.Add(lblHost);
            grpPorts.Controls.Add(lineHost);
            grpPorts.Controls.Add(txtHost);
            grpPorts.Controls.Add(lblPorts);
            grpPorts.Controls.Add(linePorts);
            grpPorts.Controls.Add(chk);
            grpPorts.Controls.Add(btnPorts);

            this.Controls.Add(btnDiag);
            this.Controls.Add(btnClear);
            this.Controls.Add(btnAbout);
            this.Controls.Add(output);
            this.Controls.Add(grpPorts);
        }

        // ===== LOG TXT =====
        void Log(string t)=>output.AppendText(t+"\r\n");

        // ===== DIAG RÉSEAU COMPLET =====
        void RunDiag()
        {
            output.Clear();
            Log("=== DIAGNOSTIC RÉSEAU ===");
            Log($"Date : {DateTime.Now}");
            Log("");

            ShowLocalNetworkInfo();
            TestGatewayAndInternet();
            TestDnsResolution();

            Log("");
            Log("=== FIN DU DIAGNOSTIC ===");
        }

        void ShowLocalNetworkInfo()
        {
            Log("[1] Informations réseau locales");
            try
            {
                var nics = NetworkInterface.GetAllNetworkInterfaces()
                    .Where(n =>
                        n.OperationalStatus == OperationalStatus.Up &&
                        (n.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                         n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211));

                foreach (var nic in nics)
                {
                    var ipProps = nic.GetIPProperties();
                    var ipv4 = ipProps.UnicastAddresses
                        .FirstOrDefault(a => a.Address.AddressFamily == AddressFamily.InterNetwork);

                    var gw = ipProps.GatewayAddresses
                        .FirstOrDefault(g => g.Address.AddressFamily == AddressFamily.InterNetwork);

                    var dnsList = ipProps.DnsAddresses
                        .Where(d => d.AddressFamily == AddressFamily.InterNetwork)
                        .Select(d => d.ToString())
                        .ToArray();

                    Log($"  Interface : {nic.Name}");
                    Log($"    Type : {nic.NetworkInterfaceType}");
                    Log($"    IPv4 : {ipv4?.Address}");
                    Log($"    Masque : {ipv4?.IPv4Mask}");
                    Log($"    Passerelle : {gw?.Address}");
                    Log($"    DNS : {string.Join(", ", dnsList)}");
                    Log("");
                }
            }
            catch (Exception ex)
            {
                Log($"  [ERREUR] Impossible de lire la config réseau : {ex.Message}");
            }
        }

        void TestGatewayAndInternet()
        {
            Log("[2] Tests de connectivité (Passerelle / Internet)");

            var gateway = GetDefaultGateway();
            if (gateway == null)
            {
                Log("  Passerelle par défaut : AUCUNE (probablement pas de sortie Internet)");
            }
            else
            {
                Log($"  Passerelle par défaut : {gateway}");
                var pingGw = PingHost(gateway.ToString(), 1000);
                Log($"    Ping passerelle : {(pingGw ? "OK" : "ECHEC")}");
            }

            var pingDnsIp = "8.8.8.8";
            var pingDns = PingHost(pingDnsIp, 1000);
            Log($"  Ping DNS public ({pingDnsIp}) : {(pingDns ? "OK" : "ECHEC")}");

            var pingInternetName = "google.com";
            var pingInternet = PingHost(pingInternetName, 1500);
            Log($"  Ping Internet ({pingInternetName}) : {(pingInternet ? "OK" : "ECHEC")}");
        }

        void TestDnsResolution()
        {
            Log("");
            Log("[3] Tests DNS");

            TestResolveName("microsoft.com");
            TestResolveName("google.com");
        }

        void TestResolveName(string hostName)
        {
            try
            {
                var entry = Dns.GetHostEntry(hostName);
                var ips = entry.AddressList
                    .Where(a => a.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    .Select(a => a.ToString())
                    .ToArray();

                Log($"  Résolution {hostName} : OK -> {string.Join(", ", ips)}");
            }
            catch (Exception ex)
            {
                Log($"  Résolution {hostName} : ECHEC ({ex.Message})");
            }
        }

        IPAddress? GetDefaultGateway()
        {
            try
            {
                var nics = NetworkInterface.GetAllNetworkInterfaces()
                    .Where(n =>
                        n.OperationalStatus == OperationalStatus.Up &&
                        (n.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                         n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211));

                foreach (var nic in nics)
                {
                    var ipProps = nic.GetIPProperties();
                    var gw = ipProps.GatewayAddresses
                        .FirstOrDefault(g => g.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);

                    if (gw != null)
                        return gw.Address;
                }
            }
            catch
            {
            }
            return null;
        }

        bool PingHost(string host, int timeoutMs = 1000)
        {
            try
            {
                using (var ping = new System.Net.NetworkInformation.Ping())
                {
                    var reply = ping.Send(host, timeoutMs);
                    return reply.Status == IPStatus.Success;
                }
            }
            catch
            {
                return false;
            }
        }

        // ===== TEST PORTS TCP =====
        void TestPorts()
        {
            string host=txtHost.Text.Trim();
            if (string.IsNullOrWhiteSpace(host))
            {
                MessageBox.Show("Merci de saisir un hôte (IP ou nom).", "Diag ports",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (chk.CheckedItems.Count == 0)
            {
                MessageBox.Show("Merci de cocher au moins un port.", "Diag ports",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Log($"=== TEST PORTS sur {host} ===");

            foreach(string item in chk.CheckedItems)
            {
                int port=int.Parse(item.Split(' ')[0]);
                bool ok=Tcp(host,port);
                Log($"{host}:{port} = {(ok?"OUVERT":"FERMÉ")}");
            }
            Log("=== FIN ===");
        }

        bool Tcp(string host,int port)
        {
            try{
                using(var c=new TcpClient()){
                    var ar=c.BeginConnect(host,port,null,null);
                    if(!ar.AsyncWaitHandle.WaitOne(1000)) return false;
                    c.EndConnect(ar);
                    return true;
                }
            }catch{return false;}
        }
    }
}
